export class ShoppingList {
  constructor() {
    this._list = [];
  }

  add(item) {
    if (item == null) {
      return;
    }

    this._list.push(item);
  }

  remove(id) {
    this._list = this._list.filter((item) => item.id !== id);
  }

  toString() {
    return JSON.stringify(this._list);
  }
}

export const ShoppingItem = (text) => {
  return {
    id: (Math.random() + 1).toString(16),
    text: text,
  };
};
