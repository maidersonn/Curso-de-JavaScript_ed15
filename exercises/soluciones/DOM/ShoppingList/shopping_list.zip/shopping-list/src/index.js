import { ShoppingList, ShoppingItem } from "./shopping";

const STORAGE_ID = "shopping-list";
const shoppingList = new ShoppingList();

function renderListItem(item) {
  const theList = document.querySelector(".list");
  const newItemInput = document.querySelector("#new-item");
  const listElement = document.createElement("li");
  const newProduct = document.createElement("span");
  const buttonDelete = document.createElement("button");

  buttonDelete.classList.add("button-delete");
  buttonDelete.textContent = "Eliminar";

  buttonDelete.addEventListener("click", () => {
    listElement.remove();
    shoppingList.remove(item.id);
    localStorage.setItem(STORAGE_ID, shoppingList.toString());
  });

  newProduct.textContent = item.text;

  listElement.appendChild(newProduct);
  listElement.appendChild(buttonDelete);

  theList.appendChild(listElement);
  newItemInput.value = "";
}

function addToList() {
  const newItemInput = document.querySelector("#new-item");

  if (newItemInput.value !== "") {
    const shoppingItem = ShoppingItem(newItemInput.value);
    shoppingList.add(shoppingItem);

    localStorage.setItem(STORAGE_ID, shoppingList.toString());

    renderListItem(shoppingItem);
  }
}

const items = JSON.parse(localStorage.getItem(STORAGE_ID));
document.querySelector("#add-item").addEventListener("click", addToList);
items.forEach((item) => {
  renderListItem(item);
  shoppingList.add(item);
});
